import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Car {
	String good;
	String username;
	int a=0;
	PreparedStatement ps;
	public void car() throws ClassNotFoundException, SQLException, IOException{


		File file=new File("account.txt");
		BufferedReader br = new BufferedReader(new FileReader(file));
		username= br.readLine();
        br.close();
		DBConfing dbconfing=new DBConfing();
		Connection con=dbconfing.getCon();
		String sql="update user set goods=? where account='"+username+"'";
		ps =con.prepareStatement(sql);
        ps.setString(1, good);
        ps.executeUpdate();
        ps.close(); 
	}

}
