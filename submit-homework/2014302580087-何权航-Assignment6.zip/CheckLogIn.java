import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class CheckLogIn{
    boolean a=false;
    String account;
    String password;
	String data_account[]=new String[1000];
	String data_password[]=new String[1000];
	int count=0;
    
    public void check() throws ClassNotFoundException, SQLException{
    	DBConfing dbconfing=new DBConfing();
		Connection con=dbconfing.getCon();
        Statement st=con.createStatement();
        ResultSet rs = st.executeQuery("select * from 2014302580087_user");
        while (rs.next()) {			
    		data_account[count]= rs.getString("account");
    		data_password[count]=rs.getString("password"); 
    		count++;
    		}
        for(int i=0;i<count;i++){
        	if((data_account[i].equals(account))&&(data_password[i].equals(password))){
        		a=true;
        	}
        	}
    }
}

