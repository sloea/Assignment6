import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class CheckRegister {
    String account;
    String password;
    String m_password;
    String email;
	String data_account[]=new String[1000];
	int count=0;
	PreparedStatement ps;
	boolean a=true;//判断账号是否可用
	boolean b=false;//判断两次输入的密码是否一样
	boolean c=false;//判断是否注册成功

	public void check() throws ClassNotFoundException, SQLException{
    	DBConfing dbconfing=new DBConfing();
		Connection con=dbconfing.getCon();
		Statement st=con.createStatement();
        ResultSet rs = st.executeQuery("select * from 2014302580087_user");
        while (rs.next()){			
        	data_account[count]= rs.getString("account");
    		count++;
    		}
        for(int i=0;i<count;i++){
        	if(data_account[i].equals(account)){
        		a=false;
        	}
        }
        if(password.equals(m_password)){b=true;}
        if(a==true && b==true){
        	c=true;    		
        	String sql="insert into user(account,password,email)values(?,?,?)";
    		ps =con.prepareStatement(sql);
            ps.setString(1, account);
            ps.setString(2, password);
            ps.setString(3, email);
            ps.executeUpdate();
            ps.close();  	
        }
        con.close();
	}

}
