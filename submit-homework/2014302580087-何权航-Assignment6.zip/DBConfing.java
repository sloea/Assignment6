import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;


public class DBConfing {
	String url = "jdbc:mysql://127.0.0.1:3306/my_schema";// 数据库名称
	String username = "root";// 数据库用户名
	String password = "123456";// 数据库密码
	public java.sql.Connection getCon() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con =(Connection) DriverManager.getConnection(url , username , password ) ;
		return con;
	}
	/*public void closeCon(java.sql.Connection connection) throws Exception {
		if (connection!=null) {
			connection.close();
		}
}*/
}
