﻿import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.dyno.visual.swing.layouts.Constraints;
import org.dyno.visual.swing.layouts.GroupLayout;
import org.dyno.visual.swing.layouts.Leading;


//VS4E -- DO NOT REMOVE THIS LINE!
public class Information extends JFrame {

	private static final long serialVersionUID = 1L;
	private JButton jButton0;
	private JTextArea jTextArea0;
	private JScrollPane jScrollPane0;

	public Information() throws ClassNotFoundException, SQLException, IOException {
		initComponents();
	}

	private void initComponents() throws ClassNotFoundException, SQLException, IOException {
		setTitle("购买信息");
		setLayout(new GroupLayout());
		add(getJButton0(), new Constraints(new Leading(309, 10, 10), new Leading(53, 61, 10, 10)));
		add(getJScrollPane0(), new Constraints(new Leading(20, 265, 10, 10), new Leading(12, 145, 10, 10)));
		setSize(429, 178);
	}

	private JScrollPane getJScrollPane0() throws ClassNotFoundException, SQLException, IOException {
		if (jScrollPane0 == null) {
			jScrollPane0 = new JScrollPane();
			jScrollPane0.setViewportView(getJTextArea0());
		}
		return jScrollPane0;
	}

	private JTextArea getJTextArea0() throws ClassNotFoundException, SQLException, IOException {
		if (jTextArea0 == null) {
			jTextArea0 = new JTextArea();
			User user=new User();
			user.user();
			jTextArea0.append(user.data);
		}
		return jTextArea0;
	}

	private JButton getJButton0() {
		if (jButton0 == null) {
			jButton0 = new JButton();
			jButton0.setText("返回商店");
                jButton0.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			               dispose();
				}
			});
		}
		return jButton0;
	}

}
