import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class User {
	String data_account[]=new String[1000];
	String data_email[]=new String[1000];
	String data_goods[]=new String[1000];
	String account;
	String data;
	int count;
	public void user() throws ClassNotFoundException, SQLException, IOException{
    	DBConfing dbconfing=new DBConfing();
		Connection con=dbconfing.getCon();
        Statement st=con.createStatement();
        ResultSet rs = st.executeQuery("select * from 2014302580087_user");
        while (rs.next()) {			
    		data_account[count]= rs.getString("account");
    		data_email[count]=rs.getString("email"); 
    		data_goods[count]=rs.getString("goods"); 
    		count++;
    		}
        File file=new File("account.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
		account= br.readLine();
        br.close();
        for(int i=0;i<count;i++){
        	if(data_account[i].equals(account)){
        		data="用户名："+data_account[i]+"\r\n"+
        	         "邮箱："+data_email[i]+"\r\n"+
        		     "已买到的宠物:"+data_goods[i];
        	}
	}
	}
	}
