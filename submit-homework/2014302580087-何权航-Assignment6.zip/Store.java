﻿import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import org.dyno.visual.swing.layouts.Constraints;
import org.dyno.visual.swing.layouts.GroupLayout;
import org.dyno.visual.swing.layouts.Leading;


//VS4E -- DO NOT REMOVE THIS LINE!
public class Store extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTable jTable0;
	private JScrollPane jScrollPane0;
	private JButton jButton0;
	private JButton jButton1;
	private JButton jButton3;
	private JButton jButton4;
	private JButton jButton5;
	private JButton jButton6;
	private JButton jButton7;
	private JButton jButton8;
	private JButton jButton9;
	private JButton jButton10;
	private JButton jButton11;
	private JButton jButton2;
	private JLabel jLabel0;
	private JButton jButton12;
	private JTextArea jTextArea0;
	private JScrollPane jScrollPane1;
	private JButton jButton13;

	public Store() {
		initComponents();
	}

	private void initComponents() {
		setLayout(new GroupLayout());
		add(getJScrollPane0(), new Constraints(new Leading(12, 332, 10, 10), new Leading(14, 219, 10, 10)));
		add(getJButton0(), new Constraints(new Leading(342, 48, 10, 10), new Leading(37, 15, 10, 10)));
		add(getJButton1(), new Constraints(new Leading(342, 48, 12, 12), new Leading(53, 15, 10, 10)));
		add(getJButton3(), new Constraints(new Leading(342, 48, 12, 12), new Leading(86, 15, 12, 12)));
		add(getJButton4(), new Constraints(new Leading(342, 48, 12, 12), new Leading(103, 15, 12, 12)));
		add(getJButton5(), new Constraints(new Leading(342, 48, 12, 12), new Leading(117, 15, 10, 10)));
		add(getJButton6(), new Constraints(new Leading(342, 48, 12, 12), new Leading(133, 15, 10, 10)));
		add(getJButton7(), new Constraints(new Leading(342, 48, 12, 12), new Leading(150, 15, 12, 12)));
		add(getJButton8(), new Constraints(new Leading(342, 48, 12, 12), new Leading(166, 15, 12, 12)));
		add(getJButton9(), new Constraints(new Leading(342, 48, 12, 12), new Leading(183, 15, 12, 12)));
		add(getJButton10(), new Constraints(new Leading(342, 48, 12, 12), new Leading(199, 15, 12, 12)));
		add(getJButton2(), new Constraints(new Leading(342, 48, 12, 12), new Leading(70, 15, 12, 12)));
		add(getJLabel0(), new Constraints(new Leading(459, 10, 10), new Leading(14, 12, 12)));
		add(getJButton11(), new Constraints(new Leading(342, 48, 12, 12), new Leading(214, 15, 10, 10)));
		add(getJButton12(), new Constraints(new Leading(435, 97, 10, 10), new Leading(193, 12, 12)));
		add(getJScrollPane1(), new Constraints(new Leading(425, 130, 10, 10), new Leading(41, 142, 10, 10)));
		add(getJButton13(), new Constraints(new Leading(213, 10, 10), new Leading(251, 12, 12)));
		setSize(589, 313);
	}

	private JButton getJButton13() {
		if (jButton13 == null) {
			jButton13 = new JButton();
			jButton13.setText("查看账户信息");
			jButton13.addActionListener(new ActionListener() {
	
				public void actionPerformed(ActionEvent event) {
					Information frame;
					try {
						frame = new Information();
frame.setDefaultCloseOperation(LogIn.EXIT_ON_CLOSE);
					frame.getContentPane().setPreferredSize(frame.getSize());
					frame.pack();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
					} catch (ClassNotFoundException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					} catch (IOException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					
				}
			});
		}
		return jButton13;
	}

	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setViewportView(getJTextArea0());
		}
		return jScrollPane1;
	}

	private JTextArea getJTextArea0() {
		if (jTextArea0 == null) {
			jTextArea0 = new JTextArea();
		}
		return jTextArea0;
	}

	private JButton getJButton12() {
		if (jButton12 == null) {
			jButton12 = new JButton();
			jButton12.setText("购买");
                        jButton12.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e)
					{
					           String s=jTextArea0.getText();
					           Car car=new Car();
					           car.good=s;
                     try {
					           car.car();
					}
		    catch (ClassNotFoundException e1) {
					// TODO 自动生成的 catch 块
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO 自动生成的 catch 块
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO 自动生成的 catch 块
					e1.printStackTrace();
				}
                     JOptionPane.showMessageDialog(null, "购买成功");
					}
				});
		}
		return jButton12;
	}

	private JLabel getJLabel0() {
		if (jLabel0 == null) {
			jLabel0 = new JLabel();
			jLabel0.setText("购物车：");
		}
		return jLabel0;
	}

	private JButton getJButton2() {
		if (jButton2 == null) {
			jButton2 = new JButton();
			jButton2.setText("+");
            jButton2.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("turtle"+","+"\r\n");
				}
			});
		}
		return jButton2;
	}

	private JButton getJButton11() {
		if (jButton11 == null) {
			jButton11 = new JButton();
			jButton11.setText("+");
            jButton11.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("canary"+","+"\r\n");
				}
			});
		}
		return jButton11;
	}

	private JButton getJButton10() {
		if (jButton10 == null) {
			jButton10 = new JButton();
			jButton10.setText("+");
            jButton10.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("myna"+","+"\r\n");
				}
			});
		}
		return jButton10;
	}

	private JButton getJButton9() {
		if (jButton9 == null) {
			jButton9 = new JButton();
			jButton9.setText("+");
            jButton9.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("fish"+","+"\r\n");
				}
			});
		}
		return jButton9;
	}

	private JButton getJButton8() {
		if (jButton8 == null) {
			jButton8 = new JButton();
			jButton8.setText("+");
            jButton8.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("lizard"+","+"\r\n");
				}
			});
		}
		return jButton8;
	}

	private JButton getJButton7() {
		if (jButton7 == null) {
			jButton7 = new JButton();
			jButton7.setText("+");
            jButton7.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("snake"+","+"\r\n");
				}
			});
		}
		return jButton7;
	}

	private JButton getJButton6() {
		if (jButton6 == null) {
			jButton6 = new JButton();
			jButton6.setText("+");
            jButton6.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("rabbit"+","+"\r\n");
				}
			});
		}
		return jButton6;
	}

	private JButton getJButton5() {
		if (jButton5 == null) {
			jButton5 = new JButton();
			jButton5.setText("+");
            jButton5.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("squirrel"+","+"\r\n");
				}
			});
		}
		return jButton5;
	}

	private JButton getJButton4() {
		if (jButton4 == null) {
			jButton4 = new JButton();
			jButton4.setText("+");
            jButton4.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("hamster"+","+"\r\n");
				}
			});
		}
		return jButton4;
	}

	private JButton getJButton3() {
		if (jButton3 == null) {
			jButton3 = new JButton();
			jButton3.setText("+");
            jButton3.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("parrot"+","+"\r\n");
				}
			});
		}
		return jButton3;
	}

	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setText("+");
            jButton1.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("cat"+","+"\r\n");
				}
			});
		}
		return jButton1;
	}

	private JButton getJButton0() {
		if (jButton0 == null) {
			jButton0 = new JButton();
			jButton0.setText("+");
            jButton0.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			          jTextArea0.append("dog"+","+"\r\n");
				}
			});

		}
		return jButton0;
	}

	private JTable getJTable0() {
		if (jTable0 == null) {
			jTable0 = new JTable();
			Pet pet=new Pet();
			try {
				pet.pet();
			} catch (ClassNotFoundException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			jTable0.setModel(new DefaultTableModel(new Object[][] { { pet.name[0], pet.eat[0], pet.drink[0], pet.live[0], pet.hobby[0], }, { pet.name[1], pet.eat[1], pet.drink[1], pet.live[1], pet.hobby[1], },
					{pet.name[2], pet.eat[2], pet.drink[2], pet.live[2], pet.hobby[2], }, {pet.name[3], pet.eat[3], pet.drink[3], pet.live[3], pet.hobby[3],}, {pet.name[4], pet.eat[4], pet.drink[4], pet.live[4], pet.hobby[4], },
					{pet.name[5], pet.eat[5], pet.drink[5], pet.live[5], pet.hobby[5], }, { pet.name[6], pet.eat[6], pet.drink[6], pet.live[6], pet.hobby[6], }, { pet.name[7], pet.eat[7], pet.drink[7], pet.live[7], pet.hobby[7], },
					{pet.name[8], pet.eat[8], pet.drink[8], pet.live[8], pet.hobby[8], }, { pet.name[9], pet.eat[9], pet.drink[9], pet.live[9], pet.hobby[9], }, { pet.name[10], pet.eat[10], pet.drink[10], pet.live[10], pet.hobby[10], },
					{ pet.name[11], pet.eat[11], pet.drink[11], pet.live[11], pet.hobby[11],}, }, new String[] { "name", "food", "drink", "live", "hobby", }) {
				private static final long serialVersionUID = 1L;
				Class<?>[] types = new Class<?>[] { Object.class, Object.class, String.class, String.class, String.class, };
	
				public Class<?> getColumnClass(int columnIndex) {
					return types[columnIndex];
				}
			});
		}
		return jTable0;
	}

	private JScrollPane getJScrollPane0() {
		if (jScrollPane0 == null) {
			jScrollPane0 = new JScrollPane();
			jScrollPane0.setViewportView(getJTable0());
		}
		return jScrollPane0;
	}

}
