﻿import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.dyno.visual.swing.layouts.Constraints;
import org.dyno.visual.swing.layouts.GroupLayout;
import org.dyno.visual.swing.layouts.Leading;


//VS4E -- DO NOT REMOVE THIS LINE!
public class Register extends JFrame {

	private static final long serialVersionUID = 1L;
	private JLabel jLabel0;
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JButton jButton0;
	private JButton jButton1;
	private JTextField jTextField0;
	private JTextField jTextField3;
	private JPasswordField jPasswordField0;
	private JPasswordField jPasswordField1;

	public Register() {
		initComponents();
	}

	private void initComponents() {
		setTitle("注册界面");
		setLayout(new GroupLayout());
		add(getJLabel0(), new Constraints(new Leading(35, 66, 10, 10), new Leading(33, 24, 10, 10)));
		add(getJLabel1(), new Constraints(new Leading(35, 66, 12, 12), new Leading(69, 24, 12, 12)));
		add(getJLabel2(), new Constraints(new Leading(33, 66, 10, 10), new Leading(141, 24, 12, 12)));
		add(getJLabel3(), new Constraints(new Leading(33, 66, 12, 12), new Leading(105, 24, 12, 12)));
		add(getJButton0(), new Constraints(new Leading(91, 10, 10), new Leading(181, 10, 10)));
		add(getJButton1(), new Constraints(new Leading(186, 10, 10), new Leading(181, 12, 12)));
		add(getJTextField0(), new Constraints(new Leading(131, 131, 10, 10), new Leading(34, 12, 12)));
		add(getJTextField3(), new Constraints(new Leading(131, 131, 12, 12), new Leading(141, 12, 12)));
		add(getJPasswordField0(), new Constraints(new Leading(131, 130, 12, 12), new Leading(71, 12, 12)));
		add(getJPasswordField1(), new Constraints(new Leading(131, 130, 12, 12), new Leading(105, 12, 12)));
		setSize(319, 236);
	}

	private JPasswordField getJPasswordField1() {
		if (jPasswordField1 == null) {
			jPasswordField1 = new JPasswordField();
			jPasswordField1.setEchoChar('•');
		}
		return jPasswordField1;
	}

	private JPasswordField getJPasswordField0() {
		if (jPasswordField0 == null) {
			jPasswordField0 = new JPasswordField();
			jPasswordField0.setEchoChar('•');
		}
		return jPasswordField0;
	}

	private JTextField getJTextField3() {
		if (jTextField3 == null) {
			jTextField3 = new JTextField();
		}
		return jTextField3;
	}

	private JTextField getJTextField0() {
		if (jTextField0 == null) {
			jTextField0 = new JTextField();
		}
		return jTextField0;
	}

	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setText("取消");
                        jButton1.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			               dispose();
				}
			});
		}
		return jButton1;
	}

	private JButton getJButton0() {
		if (jButton0 == null) {
			jButton0 = new JButton();
			jButton0.setText("确认");
            jButton0.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
			            CheckRegister check=new CheckRegister();
			            check.account=jTextField0.getText();
			            check.password=jPasswordField0.getText();
			            check.m_password=jPasswordField1.getText();
			            check.email=jTextField3.getText();
                              try{
			            check.check();
			        } catch (ClassNotFoundException e1) {
					// TODO 自动生成的 catch 块
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO 自动生成的 catch 块
					e1.printStackTrace();
}
                   if(check.a==false){
                      JOptionPane.showMessageDialog(null, "用户名已被注册");
                   }
                   
                   if(check.b==false){
                	  JOptionPane.showMessageDialog(null, "两次输入的密码不一样");
                   }          
                   if(check.c==true){
                	  dispose();
                	  JOptionPane.showMessageDialog(null, "注册成功");
                   }          
				}
			});
		}
		return jButton0;
	}

	private JLabel getJLabel3() {
		if (jLabel3 == null) {
			jLabel3 = new JLabel();
			jLabel3.setText("确认密码：");
		}
		return jLabel3;
	}

	private JLabel getJLabel2() {
		if (jLabel2 == null) {
			jLabel2 = new JLabel();
			jLabel2.setText("邮箱：");
		}
		return jLabel2;
	}

	private JLabel getJLabel1() {
		if (jLabel1 == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("密码：");
		}
		return jLabel1;
	}

	private JLabel getJLabel0() {
		if (jLabel0 == null) {
			jLabel0 = new JLabel();
			jLabel0.setText("用户名：");
		}
		return jLabel0;
	}

}
