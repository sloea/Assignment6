import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Pet {
	String name[]=new String[1000];
	String eat[]=new String[1000];
	String drink[]=new String[1000];
	String live[]=new String[1000];
	String hobby[]=new String[1000];
	int count=0;
	public void pet() throws ClassNotFoundException, SQLException{
		DBConfing dbconfing=new DBConfing();
		Connection con=dbconfing.getCon();
        Statement st=con.createStatement();
        ResultSet rs = st.executeQuery("select * from 2014302580087_pet");
        while (rs.next()) {			
    		name[count]= rs.getString("name");
    		eat[count]=rs.getString("eat"); 
    		drink[count]=rs.getString("drink");
    		live[count]=rs.getString("live");
    		hobby[count]=rs.getString("hobby");
    		count++;
    		}
	}

}
